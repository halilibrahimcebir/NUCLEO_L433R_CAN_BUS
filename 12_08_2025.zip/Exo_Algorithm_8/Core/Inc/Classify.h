/*
 * Classify.h
 *
 *  Created on: May 9, 2025
 *      Author: Administrator
 */

#ifndef INC_CLASSIFY_H_
#define INC_CLASSIFY_H_

int classify_motor_state(float* output);

#endif /* INC_CLASSIFY_H_ */
