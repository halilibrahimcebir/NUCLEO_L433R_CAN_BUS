/*
 * CAN_Encoder1_Error.h
 *
 *  Created on: Jan 28, 2025
 *      Author: seken.durmaz
 */

#ifndef INC_CAN_ENCODER1_ERROR_H_
#define INC_CAN_ENCODER1_ERROR_H_

#include "CANN_64to32.h"

void CANN_Encoder1_Error(TwointValues can_64to32values);

#endif /* INC_CAN_ENCODER1_ERROR_H_ */
