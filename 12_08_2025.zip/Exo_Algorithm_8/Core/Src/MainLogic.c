/*
 * pid.c
 *
 *  Created on: Feb 17, 2025
 *      Author: seken.durmaz
 */
#include "MainLogic.h"
#include "stm32l4xx_hal.h"
#include "CAN_Bytes_to_Float.h"
#include <math.h>
#include <stdint.h>
#include <stdio.h>
extern uint32_t TxMailbox;

int Logic() {

    new_pos_1 = f_m0_pos;
    new_pos_2 = f_m1_pos;
    f_Dif_Pos=fabs(f_m0_pos-f_m1_pos);
     pid_can_run_1 = false;
     pid_can_run_2 = false;
     VelDivCurrent_M0=f_m0_vel/f_m0_iq_setpoint;
     VelDivCurrent_M1=f_m1_vel/f_m1_iq_setpoint;

    movement_1 = old_pos_1 - new_pos_1;
    movement_2 = old_pos_2 - new_pos_2;

    old_pos_1 = new_pos_1;
    old_pos_2 = new_pos_2;




    return 0;
}
