/*
 * UART_Send_Data.h
 *
 *  Created on: Mar 12, 2025
 *      Author: Administrator
 */
#include "stdbool.h"

#ifndef INC_UART_SEND_DATA_H_
#define INC_UART_SEND_DATA_H_

void Send_Data();

extern bool UART_COM_OK;

#endif /* INC_UART_SEND_DATA_H_ */
