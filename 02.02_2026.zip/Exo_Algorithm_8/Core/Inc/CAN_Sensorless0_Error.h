/*
 * CAN_Sensorless0_Error.h
 *
 *  Created on: Feb 11, 2025
 *      Author: seken.durmaz
 */

#ifndef INC_CAN_SENSORLESS0_ERROR_H_
#define INC_CAN_SENSORLESS0_ERROR_H_

#include "CANN_64to32.h"

void CAN_Sensorless0_Error(TwointValues can_64to32values);

#endif /* INC_CAN_SENSORLESS0_ERROR_H_ */
