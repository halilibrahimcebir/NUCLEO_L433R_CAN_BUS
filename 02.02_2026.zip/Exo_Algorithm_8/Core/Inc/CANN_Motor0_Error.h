/*
 * CANN_Motor0_Error.h
 *
 *  Created on: Jan 31, 2025
 *      Author: seken.durmaz
 */

#ifndef INC_CANN_MOTOR0_ERROR_H_
#define INC_CANN_MOTOR0_ERROR_H_

#include "CANN_64to32.h"

void CANN_Motor0_Error(TwointValues can_64to32values);

#endif /* INC_CANN_MOTOR0_ERROR_H_ */
