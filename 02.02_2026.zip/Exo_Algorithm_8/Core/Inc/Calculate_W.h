/*
 * Calculate_W.h
 *
 *  Created on: Jan 7, 2026
 *      Author: Administrator
 */

#ifndef INC_CALCULATE_W_H_
#define INC_CALCULATE_W_H_



#endif /* INC_CALCULATE_W_H_ */
