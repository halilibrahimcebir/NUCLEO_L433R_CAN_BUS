#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "UART_Send_Data.h"

void Send_Data()
{
	if(UART_COM_OK)
			{
		//HAL_UART_Transmit(&huart1, (uint8_t*)message, strlen(message), 100);
			}

	else
	{

	}
}

