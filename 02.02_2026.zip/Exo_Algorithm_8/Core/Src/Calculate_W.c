/*
 * Calculate_W.c
 *
 *  Created on: Jan 7, 2026
 *      Author: Administrator
 */

#include "Calculate_W.h"
